import { Encoder } from '../encoder/encoder.js';
import { type EncodeFunction } from '../encoder/types/encode-function.js';
import { BASE64_PADDING } from '../encoder/types/methods/bytes-as-base64-string/constants.private/base64-padding.js';
import { get_float_16 } from '../functions.private/f16/get_float_16.js';
import {
  encodeAsBinaryQuotedPrintable,
  encodeAsTextQuotedPrintable,
} from '../functions.private/quoted-printable/encode-as-quoted-printable/encode-as-quoted-printable.js';
import { type DecodeFunction } from './types/decode-function.js';
import { BASE64_REVERSE_ALPHABET } from './types/methods/base64-string-as-bytes/constants.private/base64-reverse-alphabet.js';
import { BASE64_REVERSE_INVALID } from './types/methods/base64-string-as-bytes/constants.private/base64-reverse-invalid.js';
import { BASE64_REVERSE_URL_ALPHABET } from './types/methods/base64-string-as-bytes/constants.private/base64-reverse-url-alphabet.js';
import { type DecoderBase64StringAsBytesOptions } from './types/methods/base64-string-as-bytes/decoder-base64-string-as-bytes-options.js';
import { type DecoderHexStringAsBytesOptions } from './types/methods/hex-string-as-bytes/decoder-hex-string-as-bytes-options.js';
import { singleAlphanumericToNumber } from './types/methods/hex-string-as-bytes/single-alphanumeric-to-number/single-alphanumeric-to-number.js';
import {
  type DecoderStringHexOptions,
  type DecoderStringOptions,
  type DecoderStringQuotedPrintableOptions,
} from './types/methods/string/decoder-string-options.js';

/**
 * Used to _decode_ an `Uint8Array` into various kind of data.
 *
 * @example
 *
 * Decodes a _binary_ string:
 *
 * ```ts
 * const str = Decoder.decode(new Uint8Array([3, 0, 97, 98, 99]), (decoder: Decoder) => {
 *   const length: number = decoder.int16LE(); // decodes the string's length
 *   return decoder.string(length, { encoding: 'binary' }); // decodes the string as binary
 * });
 *
 * // str => 'abc'
 * ```
 */
export class Decoder {
  /**
   * Creates a new `Decoder` from some `bytes`, and immediately calls the `decode` function with this Decoder as argument.
   *
   * Then if the `Decoder` is `done`, it returns the returned value of `decode(...)`, else an `Error` is thrown.
   */
  static decode<GReturn>(bytes: Uint8Array, decode: DecodeFunction<GReturn>): GReturn {
    const decoder: Decoder = new Decoder(bytes);
    const result: GReturn = decode(decoder);
    if (!decoder.done) {
      throw new Error(`${decoder.remaining} bytes remaining.`);
    }
    return result;
  }

  /**
   * Decodes a `string`.
   */
  static string(bytes: Uint8Array, options?: DecoderStringOptions): string {
    return this.decode<string>(bytes, (decoder: Decoder): string => {
      return decoder.string(decoder.remaining, options);
    });
  }

  /**
   * Decodes a `json` value.
   */
  static json<GValue>(
    bytes: Uint8Array,
    reviver?: (this: any, key: string, value: any) => any,
  ): GValue {
    return JSON.parse(new TextDecoder().decode(bytes), reviver);
  }

  readonly #bytes: Uint8Array;
  readonly #view: DataView;
  #cursor: number;

  constructor(bytes: Uint8Array) {
    this.#bytes = bytes;
    this.#view = new DataView(this.#bytes.buffer, this.#bytes.byteOffset, this.#bytes.byteLength);
    this.#cursor = 0;
  }

  /**
   * Consumes `size` bytes.
   */
  #consume(size: number): number {
    const cursor: number = this.#cursor;
    const newCursor: number = cursor + size;

    if (newCursor > this.#bytes.length) {
      throw new Error('Size limit reached.');
    }

    this.#cursor = newCursor;

    return cursor;
  }

  /**
   * Returns the total number of bytes.
   */
  get length(): number {
    return this.#bytes.length;
  }

  /**
   * Returns the current number of consumed bytes.
   */
  get consumed(): number {
    return this.#cursor;
  }

  /**
   * Returns the remaining number of consumable bytes.
   */
  get remaining(): number {
    return this.#bytes.length - this.#cursor;
  }

  /**
   * Returns `true` if all bytes have been consumed.
   */
  get done(): boolean {
    return this.#cursor === this.#bytes.length;
  }

  // toUint8Array(): Uint8Array {
  //   return new Uint8Array(this.#bytes.buffer, this.#bytes.byteOffset, this.#cursor);
  // }
  //
  // complete(): void {
  //   if (this.#cursor !== this.#bytes.length) {
  //     throw new Error(`${this.#bytes.length - this.#cursor} bytes remaining.`);
  //   }
  // }

  // decode<GReturn>(decode: DecodeFunction<GReturn>): GReturn {
  //   return decode(this);
  // }

  // fork(length: number = this.remaining): Decoder {
  //   return new Decoder(this.#bytes.subarray(this.#cursor, this.#cursor + Math.max(0, length)));
  // }

  /**
   * Reads an `int8` from this Decoder, and moves the cursor of 1 byte for the next _read_
   */
  int8(): number {
    return this.#view.getInt8(this.#consume(1));
  }

  #int16(littleEndian: boolean): number {
    return this.#view.getInt16(this.#consume(2), littleEndian);
  }

  /**
   * Reads an `int16` represented as _little-endian_ from this Decoder.
   */
  int16LE(): number {
    return this.#int16(true);
  }

  /**
   * Reads an `int16` represented as _big-endian_ from this Decoder.
   */
  int16BE(): number {
    return this.#int16(false);
  }

  #int32(littleEndian: boolean): number {
    return this.#view.getInt32(this.#consume(4), littleEndian);
  }

  int32LE(): number {
    return this.#int32(true);
  }

  int32BE(): number {
    return this.#int32(false);
  }

  #int64(littleEndian: boolean): bigint {
    return this.#view.getBigInt64(this.#consume(8), littleEndian);
  }

  int64LE(): bigint {
    return this.#int64(true);
  }

  int64BE(): bigint {
    return this.#int64(false);
  }

  uint8(): number {
    return this.#view.getUint8(this.#consume(1));
  }

  #uint16(littleEndian: boolean): number {
    return this.#view.getUint16(this.#consume(2), littleEndian);
  }

  uint16LE(): number {
    return this.#uint16(true);
  }

  uint16BE(): number {
    return this.#uint16(false);
  }

  #uint32(littleEndian: boolean): number {
    return this.#view.getUint32(this.#consume(4), littleEndian);
  }

  uint32LE(): number {
    return this.#uint32(true);
  }

  uint32BE(): number {
    return this.#uint32(false);
  }

  #uint64(littleEndian: boolean): bigint {
    return this.#view.getBigUint64(this.#consume(8), littleEndian);
  }

  uint64LE(): bigint {
    return this.#uint64(true);
  }

  uint64BE(): bigint {
    return this.#uint64(false);
  }

  #float16(littleEndian: boolean): number {
    /* istanbul ignore if -- @preserve */
    if (this.#view.setFloat16 === undefined) {
      return get_float_16(this.#view, this.#consume(2), littleEndian);
      /* istanbul ignore else -- @preserve */
    } else {
      return this.#view.getFloat16(this.#consume(2), littleEndian);
    }
  }

  float16LE(): number {
    return this.#float16(true);
  }

  float16BE(): number {
    return this.#float16(false);
  }

  #float32(littleEndian: boolean): number {
    return this.#view.getFloat32(this.#consume(4), littleEndian);
  }

  float32LE(): number {
    return this.#float32(true);
  }

  float32BE(): number {
    return this.#float32(false);
  }

  #float64(littleEndian: boolean): number {
    return this.#view.getFloat64(this.#consume(8), littleEndian);
  }

  float64LE(): number {
    return this.#float64(true);
  }

  float64BE(): number {
    return this.#float64(false);
  }

  /**
   * Reads an `Uint8Array` from this Decoder.
   */
  bytes(length: number = this.remaining): Uint8Array {
    const index: number = this.#consume(length);
    return this.#bytes.subarray(index, index + length);
  }

  hexStringAsBytes(
    length: number = this.remaining,
    { uppercase = 'either' }: DecoderHexStringAsBytesOptions = {},
  ): Uint8Array {
    if (length % 2 !== 0) {
      throw new Error('Hex string must have an even number of characters.');
    }

    const input: Uint8Array = this.bytes(length);
    const output: Uint8Array = new Uint8Array(length / 2);

    let inputIndex: number = 0;
    let outputIndex: number = 0;

    while (inputIndex < length) {
      output[outputIndex++] =
        (singleAlphanumericToNumber(input[inputIndex++], uppercase) << 4) |
        singleAlphanumericToNumber(input[inputIndex++], uppercase);
    }

    return output;
  }

  base64StringAsBytes(
    length: number = this.remaining,
    { alphabet = 'base64', omitPadding = false }: DecoderBase64StringAsBytesOptions = {},
  ): Uint8Array {
    if (omitPadding) {
      if (length % 4 === 1) {
        throw new Error(
          'Base64 string without padding got 1 extra character which is not allowed (allowed: 0, 2, 3).',
        );
      }
    } else {
      if (length % 4 !== 0) {
        throw new Error('Base64 string must have a number of characters multiple of 4.');
      }
    }

    const ALPHABET: Uint8Array =
      alphabet === 'base64' ? BASE64_REVERSE_ALPHABET : BASE64_REVERSE_URL_ALPHABET;

    const input: Uint8Array = this.bytes(length);
    let inputLengthWithoutPadding: number = length;

    if (!omitPadding && length > 0) {
      if (input[length - 1] === BASE64_PADDING) {
        inputLengthWithoutPadding--;
      }
      if (input[length - 2] === BASE64_PADDING) {
        inputLengthWithoutPadding--;
      }
    }

    const inputLengthWithoutPaddingDiv4: number = inputLengthWithoutPadding / 4;
    const inputLengthWithoutPaddingDiv4Floored: number = Math.floor(inputLengthWithoutPaddingDiv4);
    const inputLastSafeIndex: number = inputLengthWithoutPaddingDiv4Floored * 4;
    const inputRemainingLength: number = inputLengthWithoutPadding - inputLastSafeIndex; // 0, 2, or 3

    const outputLength: number =
      inputLengthWithoutPaddingDiv4Floored * 3 +
      (inputRemainingLength === 0 ? 0 : inputRemainingLength === 2 ? 1 : 2);
    const output: Uint8Array = new Uint8Array(outputLength);

    let inputIndex: number = 0;
    let outputIndex: number = 0;

    const readByte = (): number /* [0, 0x3f] <=> 6bits */ => {
      const byte: number = ALPHABET[input[inputIndex++]];

      if (byte === BASE64_REVERSE_INVALID) {
        inputIndex--;
        throw new Error(
          `Invalid base64 char ${JSON.stringify(input[inputIndex])} at ${inputIndex}.`,
        );
      }

      return byte;
    };

    while (inputIndex < inputLastSafeIndex) {
      const triplet: number =
        (readByte() << 18) | (readByte() << 12) | (readByte() << 6) | readByte();

      output[outputIndex++] = (triplet >> 16) & 0xff;
      output[outputIndex++] = (triplet >> 8) & 0xff;
      output[outputIndex++] = triplet & 0xff;
    }

    if (inputRemainingLength === 2) {
      const doublet: number = (readByte() << 6) | readByte();

      output[outputIndex++] = (doublet >> 4) & 0xff;
    } else if (inputRemainingLength === 3) {
      const doublet: number = (readByte() << 12) | (readByte() << 6) | readByte(); // >> 6

      output[outputIndex++] = (doublet >> 10) & 0xff;
      output[outputIndex++] = (doublet >> 2) & 0xff;
    }

    return output;
  }

  /**
   * Reads a `string` from this Decoder.
   *
   * As strings may be encoded in various formats, the **output** string may be encoded with:
   *
   * - `utf-8` _(default)_: encodes the output string in _utf-8_ format.
   * - `binary`: encodes the output string in _binary_ format.
   * - `hex`: encodes the output string in _hex_ format (ex: `0AF3`).
   * - `base64`: encodes the output string in _base64_ format (ex: `YWJjZA==`).
   * - `quoted-printable`: encodes the output string in _quoted printable_ format (ex: `a=C3=A9b=3Dc`).
   * - any [valid labels](https://developer.mozilla.org/en-US/docs/Web/API/Encoding_API/Encodings): encodes the output string according to this format, if it is supported.
   */
  string(
    length: number = this.remaining,
    { encoding, ...options }: DecoderStringOptions = {},
  ): string {
    switch (encoding) {
      case 'binary': {
        let output: string = '';
        let j: number = this.#consume(length);
        for (let i: number = 0; i < length; i++, j++) {
          output += String.fromCharCode(this.#bytes[j]);
        }
        return output;
      }
      case 'hex': {
        // TODO => replace when widely available
        // const i: number = this.#consume(length);
        // return this.#bytes.subarray(i, i + length).toHex();
        let output: string = '';
        let j: number = this.#consume(length);
        for (let i: number = 0; i < length; i++, j++) {
          output += this.#bytes[j].toString(16).padStart(2, '0');
        }
        if ((options as Omit<DecoderStringHexOptions, 'encoding'>).uppercase) {
          output = output.toUpperCase();
        }
        return output;
      }
      case 'base64': {
        // TODO => replace when widely available
        // const i: number = this.#consume(length);
        // return this.#bytes.subarray(i, i + length).toBase64(options);
        return btoa(this.string(length, { encoding: 'binary' }));
      }
      case 'quoted-printable': {
        const { mode = 'text', sub }: Omit<DecoderStringQuotedPrintableOptions, 'encoding'> =
          options as Omit<DecoderStringQuotedPrintableOptions, 'encoding'>;

        let encode: EncodeFunction<Uint8Array>;

        switch (mode) {
          case 'text': {
            encode = encodeAsTextQuotedPrintable;
            break;
          }
          case 'binary': {
            encode = encodeAsBinaryQuotedPrintable;
            break;
          }
          default: {
            throw new Error(`Invalid mode: ${mode}`);
          }
        }

        return Decoder.string(Encoder.encode(this.bytes(length), encode), sub);
      }
      default:
        return new TextDecoder(encoding, options as TextDecoderOptions).decode(this.bytes(length));
    }
  }

  /**
   * Reads `length` bytes from this Decoder as string, and returns `JSON.parse(...)` of this string.
   */
  json<GValue>(
    length: number = this.remaining,
    reviver?: (this: any, key: string, value: any) => any,
  ): GValue {
    return JSON.parse(this.string(length), reviver);
  }

  /* ---- */

  /* ---- */

  // decodeInto(encoder: Encoder, decode: DecodeIntoFunction): this {
  //   decode(this, encoder);
  //   return this;
  // }
}

/*----*/

/*----*/

// export interface DecodeIntoFunction {
//   (decoder: Decoder, encoder: Encoder): void;
// }

/*---*/

// const a = new Decoder(
//   new Encoder()
//     .bytesAsHexString(new Encoder().string('abc').toUint8Array())
//     .toDecoder()
//     .hexStringAsBytes(6),
// ).string(3);

// const a = new Encoder().bytesAsHexString(Encoder.string('abc')).toDecoder().string(6);
