import { type DecoderBase64StringAsBytesOptions } from '../../../../decoder/types/methods/base64-string-as-bytes/decoder-base64-string-as-bytes-options.js';
import { type DecoderHexStringAsBytesOptions } from '../../../../decoder/types/methods/hex-string-as-bytes/decoder-hex-string-as-bytes-options.js';

export interface EncoderStringUtf8Options {
  readonly encoding?: 'utf-8';
}

export interface EncoderStringBinaryOptions {
  readonly encoding: 'binary';
}

export interface EncoderStringHexOptions extends DecoderHexStringAsBytesOptions {
  readonly encoding: 'hex';
}

export interface EncoderStringBase64Options extends DecoderBase64StringAsBytesOptions {
  readonly encoding: 'base64';
}

/**
 * @deprecated
 */
export interface EncoderStringQuotedPrintableOptions {
  readonly encoding: 'quoted-printable';
  readonly mode?: 'text' | 'binary'; // TODO remove
  readonly sub?: EncoderStringUtf8Options | EncoderStringBinaryOptions;
}

export type EncoderStringOptions =
  | EncoderStringUtf8Options
  | EncoderStringBinaryOptions
  | EncoderStringHexOptions
  | EncoderStringBase64Options;
