export interface EncoderBytesAsBase64StringOptions {
  readonly alphabet?: 'base64' | 'base64url';
  readonly omitPadding?: boolean;
}
