import { Decoder } from '../decoder/decoder.js';
import { DecoderBase64StringAsBytesOptions } from '../decoder/types/methods/base64-string-as-bytes/decoder-base64-string-as-bytes-options.js';
import { DecoderHexStringAsBytesOptions } from '../decoder/types/methods/hex-string-as-bytes/decoder-hex-string-as-bytes-options.js';
import { set_float_16 } from '../functions.private/f16/set_float_16.js';
import { type EncodeFunction } from './types/encode-function.js';
import { BASE64_ALPHABET } from './types/methods/bytes-as-base64-string/constants.private/base64-alphabet.js';
import { BASE64_PADDING } from './types/methods/bytes-as-base64-string/constants.private/base64-padding.js';
import { BASE64_URL_ALPHABET } from './types/methods/bytes-as-base64-string/constants.private/base64-url-alphabet.js';
import { EncoderBytesAsBase64StringOptions } from './types/methods/bytes-as-base64-string/encoder-bytes-as-base64-string-options.js';
import { EncoderBytesAsHexStringOptions } from './types/methods/bytes-as-hex-string/encoder-bytes-as-hex-string-options.js';
import { numberToSingleAlphanumeric } from './types/methods/bytes-as-hex-string/number-to-single-alphanumeric/number-to-single-alphanumeric.js';
import { type EncoderStringOptions } from './types/methods/string/encoder-string-options.js';

/**
 * The optional options to provide to an `Encoder`.
 */
export interface EncoderOptions {
  /**
   * The _initial_ allocated byte length
   *
   * - _range_: `[0, 0x100000000]`
   *
   * @default 0x100
   */
  readonly initialByteLength?: number;

  /**
   * The _max_ allocated byte length
   *
   * - _range_: `[initialByteLength, 0x100000000]`
   *
   * @default 0x100000000
   */
  readonly maxByteLength?: number;
}

/**
 * Used to _encode_ various kind of data into an `Uint8Array`.
 *
 * @example
 *
 * Encodes a _binary_ string:
 *
 * ```ts
 * const str: string = 'abc';
 *
 * const bytes = new Encoder()
 *  .int16LE(str.length) // encodes the string's length
 *  .string(str, { encoding: 'binary' }) // encodes the string as binary
 *  .toUint8Array();
 *
 *  // bytes => [3, 0, 97, 98, 99]
 * ```
 */
export class Encoder {
  /**
   * Creates a new `Encoder` and immediately calls the `encode` function with this Encoder and the provided value as arguments.
   *
   * Then, it returns the resulting Uint8Array containing the encoded value.
   *
   * @example:
   *
   * ```ts
   * function encodeBinaryString(encoder: Encoder, input: string): void {
   *   encoder
   *     .int16LE(input)
   *     .string(input, { encoding: 'binary' });
   * }
   *
   * const bytes = Encoder.encode('abc', encodeBinaryString);
   * ```
   */
  static encode<GValue>(
    value: GValue,
    encode: EncodeFunction<GValue>,
    options?: EncoderOptions,
  ): Uint8Array {
    return new Encoder(options).encode(value, encode).toUint8Array();
  }

  /**
   * Encodes a `string`.
   */
  static string(value: string, options?: EncoderStringOptions): Uint8Array {
    return this.encode<string>(value, (encoder: Encoder): void => {
      encoder.string(value, options);
    });
  }

  /**
   * Encodes a `json` value.
   */
  static json(
    value: any,
    replacer?: (this: any, key: string, value: any) => any,
    space?: string | number,
  ): Uint8Array {
    return new TextEncoder().encode(JSON.stringify(value, replacer, space));
  }

  // the raw buffer containing the bytes.
  readonly #buffer: ArrayBuffer;
  // a DataView on this buffer.
  readonly #view: DataView;
  // an Uint8Array on this buffer.
  readonly #bytes: Uint8Array;
  // the current number of allocated bytes (defines where we should write next).
  #cursor: number;

  constructor({ initialByteLength = 0x100, maxByteLength = 0x100000000 }: EncoderOptions = {}) {
    initialByteLength = Math.max(0, Math.min(0x100000000, Math.floor(initialByteLength)));
    maxByteLength = Math.max(initialByteLength, Math.min(0x100000000, Math.floor(maxByteLength)));

    this.#buffer = new ArrayBuffer(initialByteLength, {
      maxByteLength,
    });
    this.#view = new DataView(this.#buffer);
    this.#bytes = new Uint8Array(this.#buffer);
    this.#cursor = 0;
  }

  /**
   * Allocates `size` bytes.
   *
   * > **INFO:** resizes the `#buffer` if required.
   */
  #alloc(size: number): number {
    const cursor: number = this.#cursor;
    const newCursor: number = cursor + size;

    if (newCursor > this.#buffer.maxByteLength) {
      throw new Error('Size limit reached.');
    }

    if (newCursor > this.#buffer.byteLength) {
      this.#buffer.resize(
        Math.min(
          this.#buffer.maxByteLength,
          (1 <<
            Math.ceil(
              Math.log2(newCursor) /* number of bytes to store the data */ +
                0.5 /* adds a "half-byte" of margin */,
            )) /* round to the upper limit */ >>>
            0,
        ),
      );
    }

    this.#cursor = newCursor;

    return cursor;
  }

  /**
   * Returns the current number of written bytes.
   */
  get length(): number {
    return this.#cursor;
  }

  /**
   * Returns an `Uint8Array` containing the encoded values.
   */
  toUint8Array(): Uint8Array {
    return new Uint8Array(this.#buffer, 0, this.#cursor);
  }

  toDecoder(): Decoder {
    return new Decoder(this.toUint8Array());
  }

  /*
     INFO: All the following methods return `this`, enabling us to chain them.
     INFO: Each _write_ moves the `cursor` and grows the encoded bytes.
   */

  /**
   * Calls the function `encode` with `this` and `value` as arguments.
   *
   * > **INFO:** this is useful to encode a value in this Encoder based on an external function.
   *
   * @example:
   *
   * ```ts
   * function encodeBinaryString(encoder: Encoder, input: string): void {
   *   encoder
   *     .int16LE(input)
   *     .string(input, { encoding: 'binary' });
   * }
   *
   * const bytes = new Encoder()
   *  .encode('abc', encodeBinaryString)
   *  // other operations...
   *  .toUint8Array();
   * ```
   */
  encode<GValue>(value: GValue, encode: EncodeFunction<GValue>): this {
    encode(this, value);
    return this;
  }

  /**
   * Writes an `int8` in this Encoder, and moves the cursor of 1 byte for the next _write_
   */
  int8(value: number): this {
    this.#view.setInt8(this.#alloc(1), value);
    return this;
  }

  #int16(value: number, littleEndian: boolean): this {
    this.#view.setInt16(this.#alloc(2), value, littleEndian);
    return this;
  }

  /**
   * Writes an `int16` represented as _little-endian_ in this Encoder.
   */
  int16LE(value: number): this {
    return this.#int16(value, true);
  }

  /**
   * Writes an `int16` represented as _big-endian_ in this Encoder.
   */
  int16BE(value: number): this {
    return this.#int16(value, false);
  }

  #int32(value: number, littleEndian: boolean): this {
    this.#view.setInt32(this.#alloc(4), value, littleEndian);
    return this;
  }

  int32LE(value: number): this {
    return this.#int32(value, true);
  }

  int32BE(value: number): this {
    return this.#int32(value, false);
  }

  #int64(value: bigint | number, littleEndian: boolean): this {
    this.#view.setBigInt64(
      this.#alloc(8),
      typeof value === 'number' ? BigInt(value) : value,
      littleEndian,
    );
    return this;
  }

  int64LE(value: bigint | number): this {
    return this.#int64(value, true);
  }

  int64BE(value: bigint | number): this {
    return this.#int64(value, false);
  }

  uint8(value: number): this {
    this.#view.setUint8(this.#alloc(1), value);
    return this;
  }

  #uint16(value: number, littleEndian: boolean): this {
    this.#view.setUint16(this.#alloc(2), value, littleEndian);
    return this;
  }

  uint16LE(value: number): this {
    return this.#uint16(value, true);
  }

  uint16BE(value: number): this {
    return this.#uint16(value, false);
  }

  #uint32(value: number, littleEndian: boolean): this {
    this.#view.setUint32(this.#alloc(4), value, littleEndian);
    return this;
  }

  uint32LE(value: number): this {
    return this.#uint32(value, true);
  }

  uint32BE(value: number): this {
    return this.#uint32(value, false);
  }

  #uint64(value: bigint | number, littleEndian: boolean): this {
    this.#view.setBigUint64(
      this.#alloc(8),
      typeof value === 'number' ? BigInt(value) : value,
      littleEndian,
    );
    return this;
  }

  uint64LE(value: bigint | number): this {
    return this.#uint64(value, true);
  }

  uint64BE(value: bigint | number): this {
    return this.#uint64(value, false);
  }

  #float16(value: number, littleEndian: boolean): this {
    /* istanbul ignore if -- @preserve */
    if (this.#view.setFloat16 === undefined) {
      set_float_16(this.#view, this.#alloc(2), value, littleEndian);
      /* istanbul ignore else -- @preserve */
    } else {
      this.#view.setFloat16(this.#alloc(2), value, littleEndian);
    }
    return this;
  }

  float16LE(value: number): this {
    return this.#float16(value, true);
  }

  float16BE(value: number): this {
    return this.#float16(value, false);
  }

  #float32(value: number, littleEndian: boolean): this {
    this.#view.setFloat32(this.#alloc(4), value, littleEndian);
    return this;
  }

  float32LE(value: number): this {
    return this.#float32(value, true);
  }

  float32BE(value: number): this {
    return this.#float32(value, false);
  }

  #float64(value: number, littleEndian: boolean): this {
    this.#view.setFloat64(this.#alloc(8), value, littleEndian);
    return this;
  }

  float64LE(value: number): this {
    return this.#float64(value, true);
  }

  float64BE(value: number): this {
    return this.#float64(value, false);
  }

  /**
   * Writes an `Uint8Array` in this Encoder.
   */
  bytes(bytes: Uint8Array): this {
    this.#bytes.set(bytes, this.#alloc(bytes.length));
    return this;
  }

  /**
   * Writes `bytes` as a _hex string_ in this Encoder.
   *
   * @example:
   *
   * ```ts
   *  new Encoder()
   *    .bytesAsBase64String(new Uint8Array([0xd1, 0xc2]))
   *    .toDecoder()
   *    .string();
   * // => 'd1c2'
   * ```
   */
  bytesAsHexString(
    bytes: Uint8Array,
    { uppercase = false }: EncoderBytesAsHexStringOptions = {},
  ): this {
    let inputIndex: number = 0;
    let outputIndex: number = this.#alloc(bytes.length * 2);

    while (inputIndex < bytes.length) {
      const byte: number = bytes[inputIndex++];

      this.#bytes[outputIndex++] = numberToSingleAlphanumeric(byte >> 4, uppercase);
      this.#bytes[outputIndex++] = numberToSingleAlphanumeric(byte & 0x0f, uppercase);
    }

    return this;
  }

  bytesAsBase64String(
    bytes: Uint8Array,
    { alphabet = 'base64', omitPadding = false }: EncoderBytesAsBase64StringOptions = {},
  ): this {
    // https://datatracker.ietf.org/doc/html/rfc4648

    const ALPHABET: Uint8Array = alphabet === 'base64' ? BASE64_ALPHABET : BASE64_URL_ALPHABET;

    const inputLengthDiv3: number = bytes.length / 3;
    const inputLengthDiv3Floored: number = Math.floor(inputLengthDiv3);
    const inputLastSafeIndex: number = inputLengthDiv3Floored * 3;
    const inputRemainingLength: number = bytes.length - inputLastSafeIndex; // bytes.length % 3 <=> 0, 1, or 2

    const outputLength: number =
      inputLengthDiv3Floored * 4 +
      (inputRemainingLength === 0 ? 0 : omitPadding ? (inputRemainingLength === 1 ? 2 : 3) : 4);

    let inputIndex: number = 0;
    let outputIndex: number = this.#alloc(outputLength);

    while (inputIndex < inputLastSafeIndex) {
      const triplet: number =
        (bytes[inputIndex++] << 16) | (bytes[inputIndex++] << 8) | bytes[inputIndex++];

      this.#bytes[outputIndex++] = ALPHABET[(triplet >> 18) & 0x3f];
      this.#bytes[outputIndex++] = ALPHABET[(triplet >> 12) & 0x3f];
      this.#bytes[outputIndex++] = ALPHABET[(triplet >> 6) & 0x3f];
      this.#bytes[outputIndex++] = ALPHABET[triplet & 0x3f];
    }

    if (inputRemainingLength === 1) {
      const byte: number = bytes[inputIndex++];

      // NOTE: if byte <= 0b00111111 AND omitPadding === true, should we add only 1 character ?.

      this.#bytes[outputIndex++] = ALPHABET[(byte >> 2) & 0x3f];
      this.#bytes[outputIndex++] = ALPHABET[(byte << 4) & 0x3f];

      if (!omitPadding) {
        this.#bytes[outputIndex++] = BASE64_PADDING;
        this.#bytes[outputIndex++] = BASE64_PADDING;
      }
    } else if (inputRemainingLength === 2) {
      const doublet: number = (bytes[inputIndex++] << 8) | bytes[inputIndex++];

      this.#bytes[outputIndex++] = ALPHABET[(doublet >> 10) & 0x3f];
      this.#bytes[outputIndex++] = ALPHABET[(doublet >> 4) & 0x3f];
      this.#bytes[outputIndex++] = ALPHABET[(doublet << 2) & 0x3f];

      if (!omitPadding) {
        this.#bytes[outputIndex++] = BASE64_PADDING;
      }
    }

    return this;
  }

  // arrayBufferView(
  //   value:
  //     | Uint8Array
  //     | Uint16Array
  //     | Uint32Array
  //     | BigUint64Array
  //     | Int8Array
  //     | Int16Array
  //     | Int32Array
  //     | BigInt64Array
  //     | Float16Array
  //     | Float32Array
  //     | Float64Array,
  //   littleEndian: boolean = this.#littleEndian,
  // ): void {
  //   if (value instanceof Uint8Array) {
  //     this.bytes(value);
  //   } else {
  //     if (value instanceof Int8Array || isLittleEndianPlatform() === littleEndian) {
  //       this.bytes(new Uint8Array(value.buffer, value.byteOffset, value.byteLength));
  //     } else {
  //       if (value instanceof Uint16Array) {
  //         for (let i: number = 0; i < value.length; i++) {
  //           this.uint16(value[i], littleEndian);
  //         }
  //       } else if (value instanceof Uint32Array) {
  //         for (let i: number = 0; i < value.length; i++) {
  //           this.uint32(value[i], littleEndian);
  //         }
  //       } else if (value instanceof BigUint64Array) {
  //         for (let i: number = 0; i < value.length; i++) {
  //           this.uint64(value[i], littleEndian);
  //         }
  //       } else if (value instanceof Int16Array) {
  //         for (let i: number = 0; i < value.length; i++) {
  //           this.int16(value[i], littleEndian);
  //         }
  //       } else if (value instanceof Int32Array) {
  //         for (let i: number = 0; i < value.length; i++) {
  //           this.int32(value[i], littleEndian);
  //         }
  //       } else if (value instanceof BigInt64Array) {
  //         for (let i: number = 0; i < value.length; i++) {
  //           this.int64(value[i], littleEndian);
  //         }
  //       } else if (value instanceof Float16Array) {
  //         for (let i: number = 0; i < value.length; i++) {
  //           this.float16(value[i], littleEndian);
  //         }
  //       } else if (value instanceof Float32Array) {
  //         for (let i: number = 0; i < value.length; i++) {
  //           this.float32(value[i], littleEndian);
  //         }
  //       } else if (value instanceof Float64Array) {
  //         for (let i: number = 0; i < value.length; i++) {
  //           this.float64(value[i], littleEndian);
  //         }
  //       }
  //     }
  //   }
  // }

  /**
   * Writes a `string` in this Encoder.
   *
   * The provided string may have different formats:
   *
   * - `utf-8` _(default)_: assumes the string is an _utf-8 string_, encodes it, and appends the bytes into this Encoder's bytes.
   * - `binary`: assumes the string is a _binary string_, and appends each byte of this string, into this Encoder's bytes.
   * - `hex`: assumes the string is an _hex string_ (ex: `0AF3`), and appends each decoded byte of this string, into this Encoder's bytes.
   * - `base64`: assumes the string is an _base64 string_ (ex: `YWJjZA==`), and appends each decoded byte of this string, into this Encoder's bytes.
   */
  string(value: string, { encoding = 'utf-8', ...options }: EncoderStringOptions = {}): this {
    switch (encoding) {
      case 'utf-8':
        this.bytes(new TextEncoder().encode(value));
        break;
      case 'binary': {
        const length: number = value.length;
        let inputIndex: number = 0;
        let outputIndex: number = this.#alloc(length);
        while (inputIndex < length) {
          const char: number = value.charCodeAt(inputIndex++);
          if (char > 0xff) {
            inputIndex--;
            throw new RangeError(
              `Char ${JSON.stringify(value.at(inputIndex))} at ${inputIndex} out of range.`,
            );
          }
          this.#bytes[outputIndex++] = char;
        }
        break;
      }
      case 'hex': {
        this.bytes(
          new Encoder()
            .string(value, { encoding: 'binary' })
            .toDecoder()
            .hexStringAsBytes(undefined, options as DecoderHexStringAsBytesOptions),
        );
        break;
      }
      case 'base64': {
        this.bytes(
          new Encoder()
            .string(value, { encoding: 'binary' })
            .toDecoder()
            .base64StringAsBytes(undefined, options as DecoderBase64StringAsBytesOptions),
        );
        break;
      }
      default: {
        throw new Error(`Unsupported encoding: ${encoding}`);
      }
    }
    return this;
  }

  /**
   * Stringify `value` using `JSON.stringify(...)` and writes the result in this Encoder.
   */
  json(
    value: any,
    replacer?: (this: any, key: string, value: any) => any,
    space?: string | number,
  ): this {
    return this.string(JSON.stringify(value, replacer, space));
  }

  /**
   * Iterates on `values` and calls the `encode` function with `this` and each individual values.
   *
   * @example:
   *
   * ```ts
   * const bytes = new Encoder()
   *   .iterable([1, 2, 3], (encoder: Encoder, value: number): void => {
   *     encoder.uint16BE(value);
   *   })
   *   .toUint8Array();
   * ```
   */
  iterable<GValue>(values: Iterable<GValue>, encode: EncodeFunction<GValue>): this {
    for (const value of values) {
      encode(this, value);
    }
    return this;
  }
}
