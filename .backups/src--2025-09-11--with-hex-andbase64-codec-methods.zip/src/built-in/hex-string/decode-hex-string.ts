/**
 * Reads `length` bytes from this Decoder, assumes they are represented as an _hex string_,
 * decodes them, and returns the resulting bytes into a new `Decoder`.`
 *
 * @param {number} [length] The length of the bytes to read and convert.
 * @param {DecoderHexStringAsBytesOptions} [options]
 * @returns {Decoder} The decoded bytes available in a new `Decoder` instance.
 */
export function decodeFromHexString(
  length: number = this.remaining,
  { uppercase = 'either' }: DecoderHexStringAsBytesOptions = {},
): Decoder {
  if (length % 2 !== 0) {
    throw new Error('Hex string must have an even number of characters.');
  }

  const input: Uint8Array = this.bytes(length);
  const output: Uint8Array = new Uint8Array(length / 2);

  let inputIndex: number = 0;
  let outputIndex: number = 0;

  while (inputIndex < length) {
    output[outputIndex++] =
      (singleAlphanumericToNumber(input[inputIndex++], uppercase) << 4) |
      singleAlphanumericToNumber(input[inputIndex++], uppercase);
  }

  return new Decoder(output);
}
