export interface EncoderBytesAsHexStringOptions {
  readonly uppercase?: boolean;
}
