export const BASE64_PADDING = 61; // =
