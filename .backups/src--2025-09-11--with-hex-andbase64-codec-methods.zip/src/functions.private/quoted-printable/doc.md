https://datatracker.ietf.org/doc/html/rfc2045#section-6.7
https://en.wikipedia.org/wiki/Quoted-printable
https://www.webatic.com/quoted-printable-convertor
https://github.com/mathiasbynens/quoted-printable/blob/master/src/quoted-printable.js

