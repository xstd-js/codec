import { type AlphanumericMustBeUpperCase } from './single-alphanumeric-to-number/single-alphanumeric-to-number.js';

export interface DecoderHexStringAsBytesOptions {
  readonly uppercase?: AlphanumericMustBeUpperCase;
}
