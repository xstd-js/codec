export const BASE64_REVERSE_INVALID = 0xff;
