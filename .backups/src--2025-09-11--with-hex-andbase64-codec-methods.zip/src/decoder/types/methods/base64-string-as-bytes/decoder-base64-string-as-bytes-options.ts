export interface DecoderBase64StringAsBytesOptions {
  readonly alphabet?: 'base64' | 'base64url';
  readonly omitPadding?: boolean;
}
