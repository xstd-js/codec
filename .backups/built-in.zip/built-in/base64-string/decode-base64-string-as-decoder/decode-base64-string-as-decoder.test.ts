import { describe, expect, it, test } from 'vitest';
import { Encoder } from '../../../encoder/encoder.js';
import {
  decodeBase64StringAsDecoder,
  type DecodeBase64StringAsDecoderOptions,
} from './decode-base64-string-as-decoder.js';

describe('decodeBase64StringAsDecoder', () => {
  const decode = (input: string, options?: DecodeBase64StringAsDecoderOptions): string => {
    return decodeBase64StringAsDecoder(
      new Encoder().string(input, { encoding: 'binary' }).toDecoder(),
      undefined,
      options,
    ).string(undefined, {
      encoding: 'binary',
    });
  };

  test('default', () => {
    expect(decode('Zm9vYg==')).toBe('foob');
  });

  describe('errors', () => {
    it('should throw if it contains invalid chars', () => {
      expect(() => decode('&===', { omitPadding: false })).toThrow();
    });

    describe('omitPadding=false', () => {
      it('should throw if number of bytes is not a multiple of 4', () => {
        expect(() => decode('a', { omitPadding: false })).toThrow();
        expect(() => decode('ab', { omitPadding: false })).toThrow();
        expect(() => decode('abc', { omitPadding: false })).toThrow();
      });
    });

    describe('omitPadding=true', () => {
      it('should throw if number of bytes modulo 4 is equal to 1', () => {
        expect(() => decode('a', { omitPadding: true })).toThrow();
      });
    });
  });

  describe('alphabet=base64', () => {
    describe('omitPadding=false', () => {
      test('with various inputs', () => {
        const options: DecodeBase64StringAsDecoderOptions = {
          alphabet: 'base64',
          omitPadding: false,
        };

        expect(decode('', options)).toBe('');
        expect(decode('Zg==', options)).toBe('f');
        expect(decode('Zm8=', options)).toBe('fo');
        expect(decode('Zm9v', options)).toBe('foo');
        expect(decode('Zm9vYg==', options)).toBe('foob');
        expect(decode('Zm9vYmE=', options)).toBe('fooba');
        expect(decode('Zm9vYmFy', options)).toBe('foobar');
        expect(decode('0/8=', options)).toBe('Óÿ');
        expect(decode('++++', options)).toBe('ûï¾');
      });
    });

    describe('omitPadding=true', () => {
      test('with various inputs', () => {
        const options: DecodeBase64StringAsDecoderOptions = {
          alphabet: 'base64',
          omitPadding: true,
        };

        expect(decode('', options)).toBe('');
        expect(decode('Zg', options)).toBe('f');
        expect(decode('Zm8', options)).toBe('fo');
        expect(decode('Zm9v', options)).toBe('foo');
        expect(decode('Zm9vYg', options)).toBe('foob');
        expect(decode('Zm9vYmE', options)).toBe('fooba');
        expect(decode('Zm9vYmFy', options)).toBe('foobar');
        expect(decode('0/8', options)).toBe('Óÿ');
        expect(decode('++++', options)).toBe('ûï¾');
      });
    });
  });

  describe('alphabet=base64url', () => {
    describe('omitPadding=false', () => {
      test('with various inputs', () => {
        const options: DecodeBase64StringAsDecoderOptions = {
          alphabet: 'base64url',
          omitPadding: false,
        };

        expect(decode('Zm9vYmE=', options)).toBe('fooba');
        expect(decode('Zm9vYmFy', options)).toBe('foobar');
        expect(decode('0_8=', options)).toBe('Óÿ');
        expect(decode('----', options)).toBe('ûï¾');
      });
    });

    describe('omitPadding=true', () => {
      test('with various inputs', () => {
        const options: DecodeBase64StringAsDecoderOptions = {
          alphabet: 'base64url',
          omitPadding: true,
        };

        expect(decode('Zm9vYmE', options)).toBe('fooba');
        expect(decode('Zm9vYmFy', options)).toBe('foobar');
        expect(decode('0_8', options)).toBe('Óÿ');
        expect(decode('----', options)).toBe('ûï¾');
      });
    });
  });
});
