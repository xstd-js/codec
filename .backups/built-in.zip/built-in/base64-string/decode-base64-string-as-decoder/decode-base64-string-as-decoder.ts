import { Decoder } from '../../../decoder/decoder.js';
import { BASE64_PADDING } from '../../../encoder/types/methods/bytes-as-base64-string/constants.private/base64-padding.js';
import { BASE64_REVERSE_ALPHABET } from '../constants.private/base64-reverse-alphabet.js';
import { BASE64_REVERSE_INVALID } from '../constants.private/base64-reverse-invalid.js';
import { BASE64_REVERSE_URL_ALPHABET } from '../constants.private/base64-reverse-url-alphabet.js';

export interface DecodeBase64StringAsDecoderOptions {
  readonly alphabet?: 'base64' | 'base64url';
  readonly omitPadding?: boolean;
}

/**
 * Reads `length` bytes from `decoder`, assumes they are represented as an _base64 string_,
 * decodes them, and returns the resulting bytes into a new `Decoder`.`
 *
 * @param {Decoder} decoder The `Decoder` to read from.
 * @param {number} [length] The length of the bytes to read and convert.
 * @param {DecodeBase64StringAsDecoderOptions} [options]
 * @returns {Decoder} The decoded bytes available in a new `Decoder` instance.
 */
export function decodeBase64StringAsDecoder(
  decoder: Decoder,
  length: number = decoder.remaining,
  { alphabet = 'base64', omitPadding = false }: DecodeBase64StringAsDecoderOptions = {},
): Decoder {
  if (omitPadding) {
    if (length % 4 === 1) {
      throw new Error(
        'Base64 string without padding got 1 extra character which is not allowed (allowed: 0, 2, 3).',
      );
    }
  } else {
    if (length % 4 !== 0) {
      throw new Error('Base64 string must have a number of characters multiple of 4.');
    }
  }

  const ALPHABET: Uint8Array =
    alphabet === 'base64' ? BASE64_REVERSE_ALPHABET : BASE64_REVERSE_URL_ALPHABET;

  const input: Uint8Array = decoder.bytes(length);
  let inputLengthWithoutPadding: number = length;

  if (!omitPadding && length > 0) {
    if (input[length - 1] === BASE64_PADDING) {
      inputLengthWithoutPadding--;
    }
    if (input[length - 2] === BASE64_PADDING) {
      inputLengthWithoutPadding--;
    }
  }

  const inputLengthWithoutPaddingDiv4: number = inputLengthWithoutPadding / 4;
  const inputLengthWithoutPaddingDiv4Floored: number = Math.floor(inputLengthWithoutPaddingDiv4);
  const inputLastSafeIndex: number = inputLengthWithoutPaddingDiv4Floored * 4;
  const inputRemainingLength: number = inputLengthWithoutPadding - inputLastSafeIndex; // 0, 2, or 3

  const outputLength: number =
    inputLengthWithoutPaddingDiv4Floored * 3 +
    (inputRemainingLength === 0 ? 0 : inputRemainingLength === 2 ? 1 : 2);
  const output: Uint8Array = new Uint8Array(outputLength);

  let inputIndex: number = 0;
  let outputIndex: number = 0;

  const readByte = (): number /* [0, 0x3f] <=> 6bits */ => {
    const byte: number = ALPHABET[input[inputIndex++]];

    if (byte === BASE64_REVERSE_INVALID) {
      inputIndex--;
      throw new Error(`Invalid base64 char ${JSON.stringify(input[inputIndex])} at ${inputIndex}.`);
    }

    return byte;
  };

  while (inputIndex < inputLastSafeIndex) {
    const triplet: number =
      (readByte() << 18) | (readByte() << 12) | (readByte() << 6) | readByte();

    output[outputIndex++] = (triplet >> 16) & 0xff;
    output[outputIndex++] = (triplet >> 8) & 0xff;
    output[outputIndex++] = triplet & 0xff;
  }

  if (inputRemainingLength === 2) {
    const doublet: number = (readByte() << 6) | readByte();

    output[outputIndex++] = (doublet >> 4) & 0xff;
  } else if (inputRemainingLength === 3) {
    const doublet: number = (readByte() << 12) | (readByte() << 6) | readByte(); // >> 6

    output[outputIndex++] = (doublet >> 10) & 0xff;
    output[outputIndex++] = (doublet >> 2) & 0xff;
  }

  return new Decoder(output);
}
