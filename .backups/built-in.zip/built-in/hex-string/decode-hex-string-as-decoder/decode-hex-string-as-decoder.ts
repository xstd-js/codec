import { Decoder } from '../../../decoder/decoder.js';
import {
  type AlphanumericMustBeUpperCase,
  singleAlphanumericToNumber,
} from '../helpers/single-alphanumeric-to-number/single-alphanumeric-to-number.js';

export interface DecodeHexStringAsDecoderOptions {
  readonly uppercase?: AlphanumericMustBeUpperCase;
}

/**
 * Reads `length` bytes from `decoder`, assumes they are represented as an _hex string_,
 * decodes them, and returns the resulting bytes into a new `Decoder`.`
 *
 * @param {Decoder} decoder The `Decoder` to read from.
 * @param {number} [length] The length of the bytes to read and convert.
 * @param {DecodeHexStringAsDecoderOptions} [options]
 * @returns {Decoder} The decoded bytes available in a new `Decoder` instance.
 */
export function decodeHexStringAsDecoder(
  decoder: Decoder,
  length: number = decoder.remaining,
  { uppercase = 'either' }: DecodeHexStringAsDecoderOptions = {},
): Decoder {
  if (length % 2 !== 0) {
    throw new Error('Hex string must have an even number of characters.');
  }

  const input: Uint8Array = decoder.bytes(length);
  const output: Uint8Array = new Uint8Array(length / 2);

  let inputIndex: number = 0;
  let outputIndex: number = 0;

  while (inputIndex < length) {
    output[outputIndex++] =
      (singleAlphanumericToNumber(input[inputIndex++], uppercase) << 4) |
      singleAlphanumericToNumber(input[inputIndex++], uppercase);
  }

  return new Decoder(output);
}
