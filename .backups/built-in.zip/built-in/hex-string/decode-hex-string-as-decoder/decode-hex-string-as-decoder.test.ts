import { describe, expect, it, test } from 'vitest';
import { Encoder } from '../../../encoder/encoder.js';
import {
  decodeHexStringAsDecoder,
  type DecodeHexStringAsDecoderOptions,
} from './decode-hex-string-as-decoder.js';

describe('decodeHexString', () => {
  const decode = (input: string, options?: DecodeHexStringAsDecoderOptions): string => {
    return decodeHexStringAsDecoder(
      new Encoder().string(input, { encoding: 'binary' }).toDecoder(),
      undefined,
      options,
    ).string(undefined, {
      encoding: 'binary',
    });
  };

  it('should throw if number of bytes is not a multiple of 2', () => {
    expect(() => decode('f31')).toThrow();
  });

  describe('uppercase=either', () => {
    test('bytes sequence', () => {
      expect(decode('f31A')).toBe('\xf3\x1a');
    });
  });

  describe('uppercase=no', () => {
    const options: DecodeHexStringAsDecoderOptions = {
      uppercase: 'no',
    };

    test('valid bytes sequence', () => {
      expect(decode('f31a', options)).toBe('\xf3\x1a');
    });

    test('invalid bytes sequence', () => {
      expect(() => decode('F31a', options)).toThrow();
    });
  });

  describe('uppercase=yes', () => {
    const options: DecodeHexStringAsDecoderOptions = {
      uppercase: 'yes',
    };

    test('valid bytes sequence', () => {
      expect(decode('F31A', options)).toBe('\xf3\x1a');
    });

    test('invalid bytes sequence', () => {
      expect(() => decode('F31a', options)).toThrow();
    });
  });
});
