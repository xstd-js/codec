import { type Encoder } from '../../../encoder/encoder.js';
import { numberToSingleAlphanumeric } from '../helpers/number-to-single-alphanumeric/number-to-single-alphanumeric.js';

export interface EncodeBytesAsHexStringOptions {
  readonly uppercase?: boolean;
}

/**
 * Writes `bytes` as a _hex string_ into `encoder`.
 *
 * @example:
 *
 * ```ts
 *  encodeBytesAsHexString(new Encoder(), new Uint8Array([0xd1, 0xc2]))
 *    .toDecoder()
 *    .string();
 * // => 'd1c2'
 * ```
 */
export function encodeBytesAsHexString<GEncoder extends Encoder>(
  encoder: GEncoder,
  bytes: Uint8Array,
  { uppercase = false }: EncodeBytesAsHexStringOptions = {},
): GEncoder {
  let inputIndex: number = 0;

  while (inputIndex < bytes.length) {
    const byte: number = bytes[inputIndex++];

    encoder.uint8(numberToSingleAlphanumeric(byte >> 4, uppercase));
    encoder.uint8(numberToSingleAlphanumeric(byte & 0x0f, uppercase));
  }

  return encoder;
}
