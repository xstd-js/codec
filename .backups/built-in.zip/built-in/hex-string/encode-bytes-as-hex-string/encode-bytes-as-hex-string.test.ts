import { describe, expect, test } from 'vitest';
import { Encoder } from '../../../encoder/encoder.js';
import { EncoderBytesAsBase64StringOptions } from '../../../encoder/types/methods/bytes-as-base64-string/encoder-bytes-as-base64-string-options.js';
import { encodeBytesAsHexString } from './encode-bytes-as-hex-string.js';

describe('encodeBytesAsHexString', () => {
  const encode = (input: string, options?: EncoderBytesAsBase64StringOptions): string => {
    return encodeBytesAsHexString(
      new Encoder(),
      new Encoder().string(input, { encoding: 'binary' }).toUint8Array(),
      options,
    )
      .toDecoder()
      .string();
  };

  describe('uppercase=false', () => {
    test('bytes sequence', () => {
      expect(new Encoder().encodeHexString(new Uint8Array([0xf3, 0x1a])).toUint8Array()).toEqual(
        new Uint8Array([
          'f'.charCodeAt(0),
          '3'.charCodeAt(0),
          '1'.charCodeAt(0),
          'a'.charCodeAt(0),
        ]),
      );
    });
  });

  describe('uppercase=true', () => {
    test('bytes sequence', () => {
      expect(
        new Encoder()
          .encodeHexString(new Uint8Array([0xf3, 0x1a]), { uppercase: true })
          .toUint8Array(),
      ).toEqual(
        new Uint8Array([
          'F'.charCodeAt(0),
          '3'.charCodeAt(0),
          '1'.charCodeAt(0),
          'A'.charCodeAt(0),
        ]),
      );
    });
  });
});
