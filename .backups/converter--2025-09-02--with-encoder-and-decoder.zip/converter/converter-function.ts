import { Decoder } from '../decoder/decoder.js';
import { Encoder } from '../encoder/encoder.js';

export interface ConverterFunction {
  (decoder: Decoder, encoder: Encoder): void;
}

// sequence[1] = numberToSingleAlphanumeric(byte >> 4, true);
// sequence[2] = numberToSingleAlphanumeric(byte & 0x0f, true);

export function convertBytesToTextQuotedPrintable(decoder: Decoder, encoder: Encoder): void {
  decoder.uint8();
}

// export class Converter {
//   static toQuotedPrintable() {}
// }

// readonly alphabet?: 'base64' | 'base64url';
