import { type Decoder } from '../../../../decoder/decoder.js';
import { type Encoder } from '../../../../encoder/encoder.js';
import { numberToSingleAlphanumeric } from './number-to-single-alphanumeric.js';

export interface ConvertBytesToHexStringOptions {
  readonly length?: number;
  readonly uppercase?: boolean;
}

export function convertBytesToHexString(
  decoder: Decoder,
  encoder: Encoder,
  { length = decoder.remaining, uppercase = false }: ConvertBytesToHexStringOptions = {},
): void {
  const input: Uint8Array = decoder.bytes(length);
  const output: Uint8Array = new Uint8Array();

  for (let i: number = 0; i < input.length; i++) {
    const byte: number = input[i];

    encoder.uint8(numberToSingleAlphanumeric(byte >> 4, uppercase));
    encoder.uint8(numberToSingleAlphanumeric(byte & 0x0f, uppercase));
  }
}
