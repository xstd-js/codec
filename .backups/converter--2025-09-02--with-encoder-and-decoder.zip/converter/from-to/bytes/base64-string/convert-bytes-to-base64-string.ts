import { type Decoder } from '../../../../decoder/decoder.js';
import { type Encoder } from '../../../../encoder/encoder.js';

export interface ConvertBytesToBase64StringOptions {
  readonly length?: number;
  readonly alphabet?: 'base64' | 'base64url';
  readonly omitPadding?: boolean;
}

const BASE64_ALPHABET = new Uint8Array([
  // A-Z
  65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88,
  89, 90,
  // a-z
  97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116,
  117, 118, 119, 120, 121, 122,
  // 0-9
  48, 49, 50, 51, 52, 53, 54, 55, 56, 57,
  // +
  43,
  // /
  47,
]);

const BASE64_PADDING = 61; // =

export function convertBytesToBase64String(
  decoder: Decoder,
  encoder: Encoder,
  {
    length = decoder.remaining,
    alphabet = 'base64',
    omitPadding = false,
  }: ConvertBytesToBase64StringOptions = {},
): void {
  const bytes: Uint8Array = decoder.bytes(length);
  const outputLength: number = Math.ceil(length / 3) * 4;

  const output = new Uint8Array(outputLength);

  for (let i: number = 0; i < bytes.length; i++) {
    const byte: number = bytes[i];

    encoder.uint8(numberToSingleAlphanumeric(byte >> 4, uppercase));
    encoder.uint8(numberToSingleAlphanumeric(byte & 0x0f, uppercase));
  }
}
