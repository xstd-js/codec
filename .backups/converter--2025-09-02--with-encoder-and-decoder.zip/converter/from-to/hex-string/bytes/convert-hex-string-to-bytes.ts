import { type Decoder } from '../../../../decoder/decoder.js';
import { type Encoder } from '../../../../encoder/encoder.js';
import {
  type AlphanumericMustBeUpperCase,
  singleAlphanumericToNumber,
} from './single-alphanumeric-to-number.js';

export interface ConvertHexStringToBytesOptions {
  readonly length?: number;
  readonly uppercase?: AlphanumericMustBeUpperCase;
}

export function convertHexStringToBytes(
  decoder: Decoder,
  encoder: Encoder,
  { length = decoder.remaining, uppercase = 'either' }: ConvertHexStringToBytesOptions = {},
): void {
  const bytes: Uint8Array = decoder.bytes(length);

  if (bytes.length % 2 !== 0) {
    throw new Error('Hex string must have an even number of characters');
  }

  for (let i: number = 0; i < bytes.length; i += 2) {
    encoder.uint8(
      (singleAlphanumericToNumber(bytes[i], uppercase) << 4) |
        singleAlphanumericToNumber(bytes[i + 1], uppercase),
    );
  }
}
